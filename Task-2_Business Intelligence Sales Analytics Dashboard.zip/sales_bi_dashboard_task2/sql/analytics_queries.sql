-- 1. Revenue by product
SELECT p.product_name, SUM(s.revenue) AS total_revenue
FROM sales s JOIN products p ON p.product_id = s.product_id
GROUP BY p.product_name ORDER BY total_revenue DESC;

-- 2. Regional performance
SELECT region, SUM(revenue) AS total_revenue, COUNT(*) AS sales_lines
FROM sales GROUP BY region ORDER BY total_revenue DESC;

-- 3. Monthly revenue trend
SELECT DATE_TRUNC('month', order_date)::date AS month,
       SUM(revenue) AS total_revenue
FROM sales GROUP BY 1 ORDER BY 1;

-- 4. Top 10 customers
SELECT customer_id, SUM(revenue) AS total_revenue
FROM sales GROUP BY customer_id ORDER BY total_revenue DESC LIMIT 10;

-- 5. CTE: products above average product revenue
WITH product_totals AS (
  SELECT p.product_name, SUM(s.revenue) AS revenue
  FROM sales s JOIN products p ON p.product_id = s.product_id
  GROUP BY p.product_name
)
SELECT * FROM product_totals
WHERE revenue > (SELECT AVG(revenue) FROM product_totals)
ORDER BY revenue DESC;

-- 6. Window function: rank products by revenue
SELECT product_name, total_revenue,
       DENSE_RANK() OVER (ORDER BY total_revenue DESC) AS revenue_rank
FROM (
  SELECT p.product_name, SUM(s.revenue) AS total_revenue
  FROM sales s JOIN products p ON p.product_id = s.product_id
  GROUP BY p.product_name
) q;

-- 7. View for dashboard use
CREATE OR REPLACE VIEW sales_dashboard_view AS
SELECT s.sale_id, s.order_id, s.order_date, s.customer_id, p.product_name,
       p.category, s.region, s.quantity, s.unit_price, s.discount,
       s.gross_sales, s.revenue, s.payment_method
FROM sales s JOIN products p ON p.product_id = s.product_id;
