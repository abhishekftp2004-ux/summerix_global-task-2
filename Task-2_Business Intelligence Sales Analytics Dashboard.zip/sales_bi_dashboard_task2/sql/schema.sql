-- Business Intelligence Sales Analytics Dashboard schema
CREATE TABLE IF NOT EXISTS customers (
    customer_id VARCHAR(20) PRIMARY KEY,
    customer_segment VARCHAR(30) NOT NULL DEFAULT 'Standard'
);

CREATE TABLE IF NOT EXISTS products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL,
    unit_price NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0)
);

CREATE TABLE IF NOT EXISTS sales (
    sale_id BIGSERIAL PRIMARY KEY,
    order_id VARCHAR(30) NOT NULL,
    order_date DATE NOT NULL,
    customer_id VARCHAR(20) REFERENCES customers(customer_id),
    product_id INTEGER REFERENCES products(product_id),
    region VARCHAR(30),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
    discount NUMERIC(5,4) NOT NULL DEFAULT 0 CHECK (discount >= 0 AND discount <= 1),
    payment_method VARCHAR(30),
    gross_sales NUMERIC(14,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    revenue NUMERIC(14,2) GENERATED ALWAYS AS (quantity * unit_price * (1 - discount)) STORED
);

CREATE INDEX IF NOT EXISTS idx_sales_order_date ON sales(order_date);
CREATE INDEX IF NOT EXISTS idx_sales_region ON sales(region);
CREATE INDEX IF NOT EXISTS idx_sales_product_id ON sales(product_id);
CREATE INDEX IF NOT EXISTS idx_sales_customer_id ON sales(customer_id);
