"""Streamlit Business Intelligence Sales Analytics Dashboard.
Run: streamlit run dashboard/app.py
"""
from pathlib import Path
import sys
import pandas as pd
import plotly.express as px
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
CLEAN = ROOT / "datasets" / "processed" / "sales_clean.csv"
RAW = ROOT / "datasets" / "raw" / "sales.csv"

st.set_page_config(page_title="Sales BI Dashboard", page_icon="📊", layout="wide")
st.title("📊 Business Intelligence Sales Analytics Dashboard")
st.caption("Task 2 | SQL • PostgreSQL • Pandas • Plotly • Streamlit")
data_path = CLEAN if CLEAN.exists() else RAW
df = pd.read_csv(data_path, parse_dates=["order_date"])
if "gross_sales" not in df:
    df["gross_sales"] = df["quantity"] * df["unit_price"]
if "revenue" not in df:
    df["revenue"] = df["gross_sales"] * (1 - df["discount"].fillna(0))
df["region"] = df["region"].fillna("Unknown")
df["month"] = pd.to_datetime(df["order_date"]).dt.to_period("M").astype(str)
df["year"] = pd.to_datetime(df["order_date"]).dt.year

st.sidebar.header("Filters")
regions = sorted(df["region"].dropna().unique().tolist())
selected_regions = st.sidebar.multiselect("Region", regions, default=regions)
products = sorted(df["product"].dropna().unique().tolist())
selected_products = st.sidebar.multiselect("Product", products, default=products)
years = sorted(df["year"].dropna().unique().tolist())
selected_years = st.sidebar.multiselect("Year", years, default=years)
filtered = df[
    df["region"].isin(selected_regions)
    & df["product"].isin(selected_products)
    & df["year"].isin(selected_years)
].copy()

if filtered.empty:
    st.warning("No rows match the selected filters. Select at least one region, product, and year.")
    st.stop()

revenue = float(filtered["revenue"].sum())
gross = float(filtered["gross_sales"].sum())
orders = int(filtered["order_id"].nunique())
customers = int(filtered["customer_id"].nunique())
avg_line_revenue = float(filtered["revenue"].mean())

c1,c2,c3,c4,c5 = st.columns(5)
c1.metric("Net Revenue", f"₹{revenue:,.0f}")
c2.metric("Gross Sales", f"₹{gross:,.0f}")
c3.metric("Unique Orders", f"{orders:,}")
c4.metric("Customers", f"{customers:,}")
c5.metric("Avg. Sales Line", f"₹{avg_line_revenue:,.0f}")

left,right = st.columns(2)
with left:
    by_month = filtered.groupby("month",as_index=False)["revenue"].sum().sort_values("month")
    st.plotly_chart(px.line(by_month,x="month",y="revenue",markers=True,title="Monthly Revenue Trend",
                            labels={"month":"Month","revenue":"Revenue (₹)"}),use_container_width=True)
with right:
    by_product = filtered.groupby("product",as_index=False)["revenue"].sum().sort_values("revenue",ascending=False)
    st.plotly_chart(px.bar(by_product,x="product",y="revenue",title="Revenue by Product",
                           labels={"product":"Product","revenue":"Revenue (₹)"}),use_container_width=True)

left,right = st.columns(2)
with left:
    by_region = filtered.groupby("region",as_index=False)["revenue"].sum().sort_values("revenue",ascending=False)
    st.plotly_chart(px.bar(by_region,x="region",y="revenue",title="Regional Performance",
                           labels={"region":"Region","revenue":"Revenue (₹)"}),use_container_width=True)
with right:
    by_category = filtered.groupby("category",as_index=False)["revenue"].sum()
    st.plotly_chart(px.pie(by_category,names="category",values="revenue",title="Revenue Share by Category",
                           hole=0.35),use_container_width=True)

st.subheader("Top Customers")
top_customers = filtered.groupby("customer_id",as_index=False).agg(
    revenue=("revenue","sum"), order_count=("order_id","nunique")
).sort_values("revenue",ascending=False).head(10)
st.dataframe(top_customers, use_container_width=True, hide_index=True)

st.subheader("Filtered Sales Data")
st.dataframe(filtered.sort_values("order_date",ascending=False),use_container_width=True,hide_index=True)
csv_bytes = filtered.to_csv(index=False).encode("utf-8")
st.download_button("Download filtered data (CSV)",data=csv_bytes,file_name="filtered_sales_report.csv",mime="text/csv")
st.caption("Revenue = quantity × unit price × (1 − discount). Dataset is synthetic practice data; results are illustrative, not real business performance.")
