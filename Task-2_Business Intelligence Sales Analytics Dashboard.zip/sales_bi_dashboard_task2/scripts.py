# The runnable Streamlit app is in dashboard/app.py.
