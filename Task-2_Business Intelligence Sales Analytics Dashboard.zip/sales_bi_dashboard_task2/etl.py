"""Load and clean sales data, optionally write it to PostgreSQL."""
from pathlib import Path
import os
import pandas as pd
from sqlalchemy import create_engine

ROOT = Path(__file__).resolve().parent
RAW_PATH = ROOT / "datasets" / "raw" / "sales.csv"
CLEAN_PATH = ROOT / "datasets" / "processed" / "sales_clean.csv"

def load_clean_data(path=RAW_PATH):
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip().str.lower()
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    for col in ["quantity", "unit_price", "discount"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.drop_duplicates()
    df = df[df["quantity"].notna() & (df["quantity"] > 0)]
    df = df[df["unit_price"].notna() & (df["unit_price"] >= 0)]
    df["region"] = df["region"].fillna("Unknown")
    df["discount"] = df["discount"].fillna(0).clip(0, 1)
    df["gross_sales"] = df["quantity"] * df["unit_price"]
    df["revenue"] = df["gross_sales"] * (1 - df["discount"])
    df["year"] = df["order_date"].dt.year
    df["month"] = df["order_date"].dt.to_period("M").astype(str)
    df["day_of_week"] = df["order_date"].dt.day_name()
    df["order_month_num"] = df["order_date"].dt.month
    df["discount_band"] = pd.cut(df["discount"], bins=[-0.001,0,0.05,0.10,1], labels=["No discount","Up to 5%","5–10%","Above 10%"], include_lowest=True)
    return df

def main():
    df = load_clean_data()
    df.to_csv(CLEAN_PATH, index=False)
    print(f"Saved {len(df)} cleaned rows to {CLEAN_PATH}")
    print("Revenue:", round(df["revenue"].sum(),2))
    print("Top product:", df.groupby("product")["revenue"].sum().idxmax())
    db_url = os.getenv("DATABASE_URL")
    if db_url:
        engine = create_engine(db_url)
        df.to_sql("sales_staging", engine, if_exists="replace", index=False, chunksize=500)
        print("Loaded sales_staging table to PostgreSQL.")
    else:
        print("DATABASE_URL not set; skipped database load.")
if __name__ == "__main__":
    main()
