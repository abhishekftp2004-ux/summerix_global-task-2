# Task 2 — Sales Analytics EDA Report

> **Dataset note:** Synthetic practice dataset. The results validate the workflow only and are not real company performance.

## Data quality
- Raw rows: 603
- Clean rows: 593
- Exact duplicate rows removed: 3
- Missing quantity rows excluded: 7
- Missing region values are represented as `Unknown`.
- Missing discount values are filled with 0 as a documented demo assumption.

## KPI summary
- Total revenue: ₹4,644,776.25
- Gross sales: ₹4,877,917.50
- Unique orders: 593
- Unique customers: 118
- Highest revenue product: Monitor
- Highest revenue region: East
- Date coverage: 2024-01-02 to 2025-12-30

## Revenue by product
| product             |          Revenue |
|:--------------------|-----------------:|
| Monitor             |      2.40453e+06 |
| Webcam              | 899682           |
| USB-C Hub           | 470212           |
| Mechanical Keyboard | 462771           |
| Wireless Mouse      | 209904           |
| Laptop Stand        | 197676           |

## Revenue by region
| region   |          Revenue |
|:---------|-----------------:|
| East     |      1.21764e+06 |
| West     |      1.02628e+06 |
| North    | 899614           |
| Central  | 852662           |
| South    | 592707           |
| Unknown  |  55878.5         |

## Monthly revenue
| month   |   Revenue |
|:--------|----------:|
| 2024-01 |  364247   |
| 2024-02 |  221538   |
| 2024-03 |  169133   |
| 2024-04 |  110185   |
| 2024-05 |  122398   |
| 2024-06 |  122796   |
| 2024-07 |   88359.5 |
| 2024-08 |  214334   |
| 2024-09 |   90052.1 |
| 2024-10 |  131246   |
| 2024-11 |  195773   |
| 2024-12 |   81870.6 |
| 2025-01 |  264751   |
| 2025-02 |  208424   |
| 2025-03 |  283350   |
| 2025-04 |  180105   |
| 2025-05 |  303288   |
| 2025-06 |   87234.5 |
| 2025-07 |  198230   |
| 2025-08 |  229930   |
| 2025-09 |  199484   |
| 2025-10 |  241276   |
| 2025-11 |  208744   |
| 2025-12 |  328024   |

## Interpretation
- Product and regional rankings are based on calculated discounted revenue, not profit.
- Monthly trends are descriptive; two calendar years are not enough to prove long-term seasonality.
- Before making business decisions, include costs, returns, targets, stock availability and business context.
